"""Immutable contracts for every PurrA-owned Provider invocation."""

from __future__ import annotations

from collections.abc import AsyncIterator, Mapping
from dataclasses import dataclass, field

from purra.contracts import (
    ContextEvidenceReceipt,
    ModelCompletion,
    ModelRequest,
    ModelStreamChunk,
    ReasoningMode,
    RunId,
    ToolChoiceMode,
    ToolSchema,
)
from purra.json_values import freeze_json_mapping
from purra.json_values import thaw_json_mapping
from purra.model_protocol import (
    InvocationOutputBudget,
    require_output_budget_matches_request,
    resolve_invocation_output_budget,
)
from purra.normalization import (
    optional_non_negative_int,
    optional_positive_int,
    optional_text,
    required_text,
)
from purra.planning_stream import PlanningScope, PLANNING_STREAM_SCHEMA
from purra.output.contracts import AgentOutputIntent, OutputCommitMode


@dataclass(frozen=True, slots=True)
class ModelInvocationContext:
    run_id: RunId
    turn_id: str | None = None
    requested_reasoning_mode: ReasoningMode = ReasoningMode.DEFAULT
    deadline_at_ms: int | None = None
    deadline_code: str = "run_deadline_exceeded"
    attempt_source_key: str | None = None
    planning_scope: PlanningScope | None = None
    planning_attempt: int = 0
    tool_argument_limits: Mapping[str, int] = field(default_factory=dict)
    context_window_tokens: int | None = None
    safety_reserve_tokens: int | None = None
    runtime_reserve_tokens: int | None = None

    def __post_init__(self) -> None:
        object.__setattr__(self, "run_id", required_text(self.run_id, "run id"))
        object.__setattr__(self, "turn_id", optional_text(self.turn_id))
        object.__setattr__(
            self,
            "requested_reasoning_mode",
            ReasoningMode(self.requested_reasoning_mode),
        )
        object.__setattr__(
            self,
            "attempt_source_key",
            optional_text(self.attempt_source_key),
        )
        object.__setattr__(
            self,
            "deadline_at_ms",
            optional_positive_int(
                self.deadline_at_ms,
                "model invocation parent deadline_at_ms",
            ),
        )
        object.__setattr__(
            self,
            "deadline_code",
            required_text(self.deadline_code, "model invocation parent deadline code"),
        )
        if self.planning_scope is not None and self.planning_scope.run_id != self.run_id:
            raise ValueError("planning scope belongs to another Run")
        if type(self.planning_attempt) is not int or self.planning_attempt < 0:
            raise ValueError("planning attempt must be a non-negative integer")
        limits = {
            required_text(name, "tool argument limit name"): int(limit)
            for name, limit in self.tool_argument_limits.items()
        }
        if any(limit <= 0 for limit in limits.values()):
            raise ValueError("tool argument limits must be positive")
        object.__setattr__(self, "tool_argument_limits", freeze_json_mapping(limits))
        object.__setattr__(
            self,
            "context_window_tokens",
            optional_positive_int(
                self.context_window_tokens,
                "model invocation context window tokens",
            ),
        )
        for name in ("safety_reserve_tokens", "runtime_reserve_tokens"):
            object.__setattr__(
                self,
                name,
                optional_non_negative_int(
                    getattr(self, name),
                    f"model invocation {name.replace('_', ' ')}",
                ),
            )


@dataclass(frozen=True, slots=True)
class AgentModelCall:
    request: ModelRequest
    output_intent: AgentOutputIntent
    commit_mode: OutputCommitMode
    output_protocol: str | None = None
    requires_full_text_validation: bool = False
    reasoning_mode: ReasoningMode = ReasoningMode.DEFAULT
    output_budget: InvocationOutputBudget | None = None
    tools: tuple[ToolSchema, ...] = ()
    tool_choice: ToolChoiceMode = ToolChoiceMode.NONE

    def __post_init__(self) -> None:
        if not isinstance(self.request, ModelRequest):
            raise TypeError("agent model call requires a ModelRequest")
        if self.output_protocol is not None and (
            self.output_protocol != PLANNING_STREAM_SCHEMA
            or self.output_intent != AgentOutputIntent.STRUCTURED_PRIVATE
            or self.commit_mode != OutputCommitMode.PRIVATE
        ):
            raise ValueError("planning protocol requires structured private output")
        intent = AgentOutputIntent(self.output_intent)
        commit_mode = OutputCommitMode(self.commit_mode)
        if intent in {
            AgentOutputIntent.EXECUTION_PUBLIC,
            AgentOutputIntent.FINAL_PUBLIC,
        } and commit_mode is not OutputCommitMode.LIVE:
            raise ValueError("public output intent must be live")
        if intent in {
            AgentOutputIntent.STRUCTURED_PRIVATE,
            AgentOutputIntent.REASONING_PRIVATE,
        } and commit_mode is OutputCommitMode.LIVE:
            raise ValueError("private output intent cannot be live")
        if not isinstance(self.requires_full_text_validation, bool):
            raise TypeError("full-text validation flag must be a boolean")
        budget = self.output_budget or resolve_invocation_output_budget(
            self.request.capability_snapshot,
            max_generation_tokens=self.request.max_generation_tokens,
        )
        if not isinstance(budget, InvocationOutputBudget):
            raise TypeError("agent model call requires an InvocationOutputBudget")
        require_output_budget_matches_request(
            budget,
            self.request.capability_snapshot,
            self.request.max_generation_tokens,
        )
        tools = tuple(self.tools)
        tool_choice = ToolChoiceMode(self.tool_choice)
        if not tools and tool_choice is ToolChoiceMode.REQUIRED:
            raise ValueError("required tool choice needs at least one tool")
        object.__setattr__(self, "output_intent", intent)
        object.__setattr__(self, "commit_mode", commit_mode)
        object.__setattr__(self, "reasoning_mode", ReasoningMode(self.reasoning_mode))
        object.__setattr__(self, "output_budget", budget)
        object.__setattr__(self, "tools", tools)
        object.__setattr__(self, "tool_choice", tool_choice)


@dataclass(frozen=True, slots=True)
class ModelInvocationReceipt:
    invocation_id: str
    output_stream_id: str
    run_id: RunId
    turn_id: str | None
    model: str
    output_intent: AgentOutputIntent
    commit_mode: OutputCommitMode
    output_budget: InvocationOutputBudget
    input_fingerprint: str
    tool_schema_fingerprint: str
    output_protocol: str | None = None
    planning_scope: PlanningScope | None = None
    planning_attempt: int = 0
    budget_key: str | None = None
    context_evidence: tuple[ContextEvidenceReceipt, ...] = field(
        default_factory=tuple
    )
    call_parameters: tuple[Mapping[str, object], ...] = field(default_factory=tuple)

    def __post_init__(self) -> None:
        object.__setattr__(
            self,
            "invocation_id",
            required_text(self.invocation_id, "invocation id"),
        )
        object.__setattr__(
            self,
            "output_stream_id",
            required_text(self.output_stream_id, "output stream id"),
        )
        object.__setattr__(self, "run_id", required_text(self.run_id, "run id"))
        object.__setattr__(self, "turn_id", optional_text(self.turn_id))
        object.__setattr__(self, "model", required_text(self.model, "model"))
        object.__setattr__(
            self,
            "output_intent",
            AgentOutputIntent(self.output_intent),
        )
        object.__setattr__(self, "commit_mode", OutputCommitMode(self.commit_mode))
        if not isinstance(self.output_budget, InvocationOutputBudget):
            raise TypeError("invocation receipt requires an output budget")
        object.__setattr__(
            self,
            "input_fingerprint",
            required_text(self.input_fingerprint, "model input fingerprint"),
        )
        object.__setattr__(
            self,
            "tool_schema_fingerprint",
            required_text(
                self.tool_schema_fingerprint,
                "model tool schema fingerprint",
            ),
        )
        object.__setattr__(self, "budget_key", optional_text(self.budget_key))
        evidence = tuple(self.context_evidence)
        if not all(isinstance(item, ContextEvidenceReceipt) for item in evidence):
            raise TypeError(
                "invocation context evidence must be ContextEvidenceReceipt values"
            )
        object.__setattr__(self, "context_evidence", evidence)
        object.__setattr__(
            self,
            "call_parameters",
            tuple(freeze_json_mapping(item) for item in self.call_parameters),
        )

    def to_mapping(self) -> dict[str, object]:
        return {
            "schemaVersion": 2,
            "invocationId": self.invocation_id,
            "outputStreamId": self.output_stream_id,
            "runId": self.run_id,
            "turnId": self.turn_id,
            "model": self.model,
            "outputIntent": self.output_intent.value,
            "commitMode": self.commit_mode.value,
            "outputBudget": self.output_budget.to_mapping(),
            "inputFingerprint": self.input_fingerprint,
            "toolSchemaFingerprint": self.tool_schema_fingerprint,
            "budgetKey": self.budget_key or self.invocation_id,
            "outputProtocol": self.output_protocol,
            "planningScope": self.planning_scope.to_mapping() if self.planning_scope else None,
            "planningAttempt": self.planning_attempt,
            "contextEvidence": [
                item.to_mapping() for item in self.context_evidence
            ],
            "callParameters": [
                thaw_json_mapping(item) for item in self.call_parameters
            ],
        }


@dataclass(frozen=True, slots=True)
class ManagedInvocationStream:
    chunks: AsyncIterator[ModelStreamChunk]
    receipt: ModelInvocationReceipt


@dataclass(frozen=True, slots=True)
class ManagedInvocationCompletion:
    completion: ModelCompletion
    receipt: ModelInvocationReceipt


__all__ = [name for name in globals() if not name.startswith("_")]
